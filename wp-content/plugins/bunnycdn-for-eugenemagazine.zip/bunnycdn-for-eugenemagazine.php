<?php
/*
Plugin Name: BunnyCDN for Eugene Magazine
Description: Rewrite all upload URLs to bunny CDN.
Version: 1.1
*/

function bcdn_em_hook_start() {
	if ( !is_plugin_active('bunnycdn/bunnycdn.php') ) {
		if ( current_user_can('administrator') ) {
			echo '<!-- BunnyCDN plugin is not active, urls will not be rewritten -->';
		}
		return;
	}
	if ( is_admin() ) return;	
	ob_start( 'bcdn_em_hook_end' );
}
add_action( 'wp', 'bcdn_em_hook_start' );

function bcdn_em_hook_end( $content ) {
	$s = '//eugenemagazine.com/wp-content/uploads/';
	$r = '//eugenemagazine.b-cdn.net/wp-content/uploads/';
	
	return str_replace( $s, $r, $content );
}